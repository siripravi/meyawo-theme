let title = anime({
    targets: '.header-title',
    duration: 2500,
    color: '#212529',
    easing: 'linear'
  });
let top_menu_select = document.getElementById('top-menu');
let top_menu = anime({
    targets: top_menu_select,
    duration: 5000,
    color: '#fff',
    easing: 'linear' 
})